package com.safeshare.controller;

import com.safeshare.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/files")
public class FileController {

    @Autowired
    private FileService fileService;

    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file,
                                        @RequestParam(value = "phone", required = false) String phone,
                                        @RequestParam(value = "email", required = false) String email,
                                        @RequestParam(value = "whatsapp", required = false) String whatsapp) {
        try {
            String code = fileService.uploadFile(file, phone, email, whatsapp);
            return ResponseEntity.ok(Map.of("code", code, "message", "File uploaded successfully!"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Upload failed: " + e.getMessage()));
        }
    }

    @PostMapping("/upload-group")
    public ResponseEntity<?> uploadFileForGroup(@RequestParam("file") MultipartFile file,
                                                @RequestParam("emails") String emailsCsv,
                                                @RequestParam(value = "whatsapp", required = false) String whatsapp) {
        try {
            String[] emails = emailsCsv.split(",");
            String code = fileService.uploadFileForGroup(file, emails, whatsapp);
            return ResponseEntity.ok(Map.of("code", code, "message", "File shared with " + emails.length + " recipients!"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Group upload failed: " + e.getMessage()));
        }
    }

    @GetMapping("/download/{code}")
    public ResponseEntity<?> downloadFile(@PathVariable String code) {
        try {
            byte[] fileData = fileService.downloadFile(code);
            String fileName = fileService.getFileName(code);

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .body(fileData);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Download failed: " + e.getMessage()));
        }
    }
}
