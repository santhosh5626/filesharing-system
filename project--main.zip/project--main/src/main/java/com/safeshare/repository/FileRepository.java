package com.safeshare.repository;

import com.safeshare.model.FileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FileRepository extends JpaRepository<FileEntity, Long> {
    
    Optional<FileEntity> findByCode(String code);

    boolean existsByCode(String code);

    // Optional: method to delete expired files
    void deleteByExpiresAtBefore(java.time.LocalDateTime dateTime);
}
