package com.safeshare.config;

import com.safeshare.model.UserEntity;
import com.safeshare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@RequiredArgsConstructor
public class DataInitializer {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initData() {
        return args -> {
            // Check if default user exists, if not create one
            if (userRepository.findByUsername("prakash").isEmpty()) {
                UserEntity user = new UserEntity();
                user.setUsername("prakash");
                user.setPassword(passwordEncoder.encode("1234"));
                user.setRole("USER");
                userRepository.save(user);
                System.out.println("Default user created: prakash/1234");
            }
        };
    }
}
