package com.safeshare.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "files")
@Data
@NoArgsConstructor
public class FileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 6)
    private String code;

    @Column(nullable = false)
    private String fileName;

    @Lob
    @Column(columnDefinition = "BLOB", nullable = false)
    private byte[] encryptedData;

    @Column(nullable = false)
    private LocalDateTime createdAt;
    
    // Optional: add expiration time if we want to delete old files automatically
    private LocalDateTime expiresAt;

    private String recipientPhoneNumber;

    private String recipientEmail;

    private String whatsappNumber;

    public FileEntity(String code, String fileName, byte[] encryptedData, String recipientPhoneNumber) {
        this.code = code;
        this.fileName = fileName;
        this.encryptedData = encryptedData;
        this.createdAt = LocalDateTime.now();
        // Set expiry for 24 hours by default
        this.expiresAt = LocalDateTime.now().plusHours(24);
        this.recipientPhoneNumber = recipientPhoneNumber;
    }
}
