package com.safeshare.service;

import com.safeshare.model.FileEntity;
import com.safeshare.repository.FileRepository;
import com.safeshare.util.EncryptionUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class FileService {

    private final FileRepository fileRepository;
    private final EmailService emailService;

    @Scheduled(cron = "0 0 * * * *")
    @Transactional
    public void cleanupExpiredFiles() {
        fileRepository.deleteByExpiresAtBefore(LocalDateTime.now());
    }

    public String uploadFile(MultipartFile file, String phone, String email, String whatsapp) throws Exception {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be empty");
        }

        byte[] encryptedData = EncryptionUtil.encrypt(file.getBytes());
        String code = generateUniqueCode();
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            originalFilename = "unknown_file";
        }

        FileEntity fileEntity = new FileEntity(code, originalFilename, encryptedData, phone);
        fileEntity.setRecipientEmail(email);
        fileEntity.setWhatsappNumber(whatsapp);
        fileRepository.save(fileEntity);

        // Send email if provided
        if (email != null && !email.trim().isEmpty()) {
            emailService.sendAccessCodeWithAttachment(email.trim(), code, originalFilename, file);
        }

        // Log whatsapp simulation
        if (whatsapp != null && !whatsapp.trim().isEmpty()) {
            System.out.println("WHATSAPP SIMULATION: Code " + code + " for file " + originalFilename + " sent to " + whatsapp);
        }

        // Log phone (SMS simulation)
        if (phone != null && !phone.trim().isEmpty()) {
            System.out.println("SIMULATING SMS TO " + phone + ": Your file access code is " + code);
        }

        return code;
    }

    public String uploadFileForGroup(MultipartFile file, String[] emails, String whatsapp) throws Exception {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be empty");
        }

        byte[] encryptedData = EncryptionUtil.encrypt(file.getBytes());
        String code = generateUniqueCode();
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            originalFilename = "unknown_file";
        }

        String allEmails = String.join(", ", emails);
        FileEntity fileEntity = new FileEntity(code, originalFilename, encryptedData, null);
        fileEntity.setRecipientEmail(allEmails);
        fileEntity.setWhatsappNumber(whatsapp);
        fileRepository.save(fileEntity);

        // Send email to all recipients
        emailService.sendAccessCodeToMultipleWithAttachment(emails, code, originalFilename, file);

        return code;
    }

    public byte[] downloadFile(String code) throws Exception {
        FileEntity fileEntity = fileRepository.findByCode(code)
                .orElseThrow(() -> new IllegalArgumentException("Invalid code or file not found"));
        return EncryptionUtil.decrypt(fileEntity.getEncryptedData());
    }

    public String getFileName(String code) {
        return fileRepository.findByCode(code)
                .map(FileEntity::getFileName)
                .orElse("unknown_file");
    }

    private String generateUniqueCode() {
        Random random = new Random();
        String code;
        do {
            code = String.format("%06d", random.nextInt(1000000));
        } while (fileRepository.existsByCode(code));
        return code;
    }
}
