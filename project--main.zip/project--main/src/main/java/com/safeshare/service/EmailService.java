package com.safeshare.service;

import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    public void sendAccessCodeWithAttachment(String toEmail, String code, String fileName, MultipartFile file) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("SafeShare - File Shared With You: " + fileName);
            helper.setText(
                "Hello!\n\n" +
                "Someone has shared a file with you via SafeShare.\n\n" +
                "File: " + fileName + "\n" +
                "Access Code: " + code + "\n\n" +
                "Attached is the document for your convenience.\n\n" +
                "Note: To download this file through the SafeShare app securely, use the access code above.\n\n" +
                "This file will expire in 24 hours.\n\n" +
                "- SafeShare by Prakashkumar J"
            );

            if (file != null && !file.isEmpty()) {
                helper.addAttachment(fileName, new ByteArrayResource(file.getBytes()));
            }

            mailSender.send(message);
            System.out.println("EMAIL SENT to " + toEmail + " with attachment: " + fileName);
        } catch (Exception e) {
            System.err.println("FAILED to send email to " + toEmail + ": " + e.getMessage());
        }
    }

    public void sendAccessCodeToMultipleWithAttachment(String[] emails, String code, String fileName, MultipartFile file) {
        for (String email : emails) {
            String trimmed = email.trim();
            if (!trimmed.isEmpty()) {
                sendAccessCodeWithAttachment(trimmed, code, fileName, file);
            }
        }
    }
}
