document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('fileInput');
    const fileInfo = document.getElementById('file-info');
    const fileNameDisplay = document.getElementById('file-name');
    const clearFileBtn = document.getElementById('clearFile');
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadResult = document.getElementById('uploadResult');
    const generatedCodeDisplay = document.getElementById('generatedCode');
    const copyBtn = document.getElementById('copyBtn');
    const emailList = document.getElementById('emailList');
    const addEmailBtn = document.getElementById('addEmailBtn');
    const emailCount = document.getElementById('emailCount');

    let selectedFile = null;

    // --- Drag and Drop ---
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('drop-zone--over');
    });

    ['dragleave', 'dragend'].forEach(type => {
        dropZone.addEventListener(type, () => {
            dropZone.classList.remove('drop-zone--over');
        });
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('drop-zone--over');
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length) {
            handleFiles(fileInput.files[0]);
        }
    });

    function handleFiles(file) {
        selectedFile = file;
        fileNameDisplay.textContent = file.name;
        dropZone.classList.add('hidden');
        fileInfo.classList.remove('hidden');
        updateUploadBtn();
        uploadResult.classList.add('hidden');
    }

    clearFileBtn.addEventListener('click', () => {
        selectedFile = null;
        fileInput.value = '';
        dropZone.classList.remove('hidden');
        fileInfo.classList.add('hidden');
        updateUploadBtn();
    });

    // --- Dynamic Email Fields ---
    function updateEmailCount() {
        const count = emailList.querySelectorAll('.email-row').length;
        emailCount.textContent = count + ' recipient' + (count !== 1 ? 's' : '');
    }

    function updateUploadBtn() {
        const emails = getValidEmails();
        uploadBtn.disabled = !selectedFile || emails.length === 0;
    }

    function getValidEmails() {
        const inputs = emailList.querySelectorAll('.group-email');
        const emails = [];
        inputs.forEach(input => {
            const val = input.value.trim();
            if (val && val.includes('@')) {
                emails.push(val);
            }
        });
        return emails;
    }

    addEmailBtn.addEventListener('click', () => {
        const row = document.createElement('div');
        row.className = 'email-row';
        row.innerHTML = `
            <input type="email" placeholder="recipient@example.com" class="group-email">
            <button class="remove-email-btn" title="Remove">
                <i class="fas fa-times"></i>
            </button>
        `;
        emailList.appendChild(row);
        updateEmailCount();
        row.querySelector('input').focus();
    });

    emailList.addEventListener('click', (e) => {
        const btn = e.target.closest('.remove-email-btn');
        if (btn) {
            const rows = emailList.querySelectorAll('.email-row');
            if (rows.length > 1) {
                btn.closest('.email-row').remove();
                updateEmailCount();
                updateUploadBtn();
            }
        }
    });

    emailList.addEventListener('input', () => {
        updateUploadBtn();
    });

    // --- Upload Logic ---
    uploadBtn.addEventListener('click', async () => {
        const emails = getValidEmails();
        const whatsappInput = document.getElementById('whatsappInput').value;
        if (!selectedFile || (emails.length === 0 && !whatsappInput)) return;

        uploadBtn.disabled = true;
        uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Encrypting & Sending...';

        const formData = new FormData();
        formData.append('file', selectedFile);
        if (emails.length > 0) {
            formData.append('emails', emails.join(','));
        }
        if (whatsappInput) {
            formData.append('whatsapp', whatsappInput);
        }

        try {
            const response = await fetch('/api/files/upload-group', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) throw new Error('Upload failed');

            const data = await response.json();
            const code = data.code;
            generatedCodeDisplay.textContent = code;
            uploadResult.classList.remove('hidden');

            // Show sent emails list
            const sentList = document.getElementById('sentList');
            const sentEmails = document.getElementById('sentEmails');
            if (emails.length > 0) {
                sentEmails.innerHTML = '';
                emails.forEach(email => {
                    const li = document.createElement('li');
                    li.innerHTML = `<i class="fas fa-check"></i> ${email}`;
                    sentEmails.appendChild(li);
                });
                sentList.classList.remove('hidden');
            } else {
                sentList.classList.add('hidden');
            }

            // --- WhatsApp Share Link ---
            const waShareContainer = document.getElementById('waShareContainer');
            const waShareBtn = document.getElementById('waShareBtn');
            if (waShareContainer && waShareBtn) {
                if (whatsappInput) {
                    const cleanPhone = whatsappInput.replace(/\D/g, '');
                    const siteUrl = window.location.origin; // This will point to index.html logic
                    const magicLink = `${siteUrl}/index.html?code=${code}`;
                    const message = encodeURIComponent(`SafeShare: Your file access code for "${selectedFile.name}" is: ${code}\n\nDownload Link: ${magicLink}`);
                    waShareBtn.href = `https://wa.me/${cleanPhone}?text=${message}`;
                    waShareContainer.classList.remove('hidden');
                } else {
                    waShareContainer.classList.add('hidden');
                }
            }

            uploadBtn.innerHTML = '<i class="fas fa-check"></i> Shared!';
        } catch (error) {
            alert('Error: ' + error.message);
            uploadBtn.innerHTML = '<i class="fas fa-share-alt"></i> Encrypt & Send to All';
            uploadBtn.disabled = false;
        }
    });

    // --- Copy Code ---
    copyBtn.addEventListener('click', () => {
        const code = generatedCodeDisplay.textContent;
        navigator.clipboard.writeText(code).then(() => {
            const originalIcon = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyBtn.innerHTML = originalIcon;
            }, 2000);
        });
    });

    // --- Receive / Download Logic ---
    const codeInput = document.getElementById('codeInput');
    const downloadBtn = document.getElementById('downloadBtn');
    const downloadMessage = document.getElementById('downloadMessage');

    codeInput.addEventListener('input', () => {
        downloadBtn.disabled = codeInput.value.length !== 6;
        downloadMessage.classList.add('hidden');
    });

    downloadBtn.addEventListener('click', async () => {
        const code = codeInput.value;
        if (code.length !== 6) return;

        downloadBtn.disabled = true;
        downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Decrypting...';

        try {
            const response = await fetch(`/api/files/download/${code}`);

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Download failed');
            }

            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;

            const disposition = response.headers.get('Content-Disposition');
            let filename = 'downloaded-file';
            if (disposition && disposition.indexOf('attachment') !== -1) {
                const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                const matches = filenameRegex.exec(disposition);
                if (matches != null && matches[1]) {
                    filename = matches[1].replace(/['"]/g, '');
                }
            }

            a.download = filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(downloadUrl);
            a.remove();

            downloadBtn.innerHTML = '<i class="fas fa-unlock"></i> Decrypt & Download';
            downloadBtn.disabled = false;
            downloadMessage.textContent = '';
            downloadMessage.classList.add('hidden');

        } catch (error) {
            downloadMessage.textContent = error.message;
            downloadMessage.classList.remove('hidden');
            downloadMessage.classList.add('error');
            downloadBtn.innerHTML = '<i class="fas fa-unlock"></i> Decrypt & Download';
            downloadBtn.disabled = false;
        }
    });

    // --- Magic Link Logic ---
    const urlParams = new URLSearchParams(window.location.search);
    const urlCode = urlParams.get('code');
    if (urlCode && codeInput) {
        codeInput.value = urlCode;
        downloadBtn.disabled = false;
    }

    // Init
    updateEmailCount();
    updateUploadBtn();
});
