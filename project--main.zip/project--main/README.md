# SafeShare - Secure & Premium File Sharing App

## 🚀 Overview
SafeShare is a professional, high-security file sharing application. It uses **AES encryption** to protect files and generates a **6-digit access code** for secure retrieval. 

Features include **Email sharing** (with attachments), **WhatsApp sharing** (direct links), and **Group Sharing** capabilities.

## 🔑 Login Credentials
The application is secured with a professional login system.
- **Username**: `prakash`
- **Password**: `1234`

## 🌟 Key Features
- **Encrypted Storage**: Files are encrypted at rest using AES.
- **Multiple Sharing Channels**:
    - **Access Code**: Share the unique 6-digit code manually.
    - **Email**: Send code and the actual file as an attachment to recipients.
    - **WhatsApp**: Direct sharing links for mobile users.
- **Group Sharing**: Dedicated dashboard to share the same file with multiple recipients at once.
- **Premium UI**: Modern dark-mode, glassmorphism design with micro-animations.
- **Persistence**: Powered by H2 File-based SQL database.

## 🛠️ How to Run

1. **Prerequisites**: Java 17+ installed.
2. **Build and Run**:
   ```powershell
   tools\apache-maven-3.9.6\bin\mvn.cmd spring-boot:run
   ```
3. **Access**:
   - Web App: `http://localhost:8080`
   - H2 Console: `http://localhost:8080/h2-console`
     - JDBC URL: `jdbc:h2:file:./data/safeshare`
     - User: `sa`
     - Password: `password`

## ⚙️ Email Configuration
To enable actual email delivery, update `src/main/resources/application.properties`:
```properties
spring.mail.username=YOUR_GMAIL@gmail.com
spring.mail.password=YOUR_APP_PASSWORD
```

---
**Developer**: Prakashkumar J
**Technology**: Spring Boot, Jakarta-Mail, JPA, H2, Vanilla CSS (Glassmorphism), JavaScript
